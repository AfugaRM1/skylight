<?php

$servername = "localhost";
$db_user = "root";
$db_password = "";
$db_name = "reservation";

$connection = mysqli_connect($servername, $db_user, $db_password, $db_name);

if(!$connection){
    die("failed to connect");
}

$name = $_POST['name'];
$email = $_POST['email'];
$order = $_POST['order'];
$date = $_POST['date'];
$Id = uniqid();
// $sql = "INSERT INTO `customers`(`Name`, `Email`, `Order`, `Date`,) VALUES ('".$name."','".$email."','".$order."','".$date."')";

$sql = "INSERT INTO `customers`(`Name`, `Email`, `Order`, `Date`, `ID`) VALUES ('".$name."','".$email."','".$order."','".$date."','".$Id."')";

// echo $sql;

if($connection->query($sql)){
    echo "Success! Your order " . $order . "on ID " . $Id . "has been placed.";
}
else{
    echo "failed";
}

?>